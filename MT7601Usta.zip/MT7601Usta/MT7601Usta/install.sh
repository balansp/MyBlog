#! /bin/bash

KERNEL_VERSION=`uname -r`

sudo rm -rf /etc/Wireless/RT2870STA
sudo mkdir -p /etc/Wireless/RT2870STA
sudo cp RT2870STA.dat /etc/Wireless/RT2870STA/.
sudo install -p -m 644 $KERNEL_VERSION/mt7601Usta.ko /lib/modules/$KERNEL_VERSION/kernel/drivers/net/wireless/
sudo depmod $KERNEL_VERSION

sudo cat >> /etc/network/interfaces << EOF

auto ra0
allow-hotplug ra0
iface ra0 inet dhcp
wpa-conf /etc/wpa_supplicant/wpa_supplicant.conf
iface default inet dhcp
EOF

sudo cat > /etc/wpa_supplicant/wpa_supplicant.conf << EOF
ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev
update_config=1

network={
    ssid="SSID HERE"
    key_mgmt=WPA-PSK
    psk="PASSWORD HERE"
}
EOF

sudo chmod 600 /etc/wpa_supplicant/wpa_supplicant.conf


#! /bin/bash

KERNEL_VERSION=`uname -r`

sudo rm -rf /etc/Wireless/RT2870STA
sudo mkdir -p /etc/Wireless/RT2870STA
sudo cp RT2870STA.dat /etc/Wireless/RT2870STA/.
sudo install -p -m 644 $KERNEL_VERSION/mt7601Usta.ko /lib/modules/$KERNEL_VERSION/kernel/drivers/net/wireless/
sudo depmod $KERNEL_VERSION


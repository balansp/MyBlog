For Raspian 3.12.22+ and 3.12.25+

Run install.sh to install the MT7601 drivers.

